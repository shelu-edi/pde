var btn = document.getElementById('form-btn')
var container = document.getElementById('pop-container')

// btn.onclick = function() {
// container.style.display = 'block'
// console.log('blah')
// }

function display() {
	container.style.display = 'block';
	console.log('blah')
	location.href = 'index.html';
}



